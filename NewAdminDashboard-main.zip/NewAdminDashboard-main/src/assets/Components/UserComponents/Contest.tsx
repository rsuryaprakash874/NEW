import React from 'react';
import './styles.css';
const Contest: React.FC = () => {
  return (
    <div className="page-container">
      <h1>Contest</h1>
      <p>View upcoming and ongoing contests.</p>
    </div>
  );
};

export default Contest;