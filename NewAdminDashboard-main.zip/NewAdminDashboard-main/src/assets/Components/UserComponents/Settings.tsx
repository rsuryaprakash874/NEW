import React from 'react';
import './styles.css';
const Settings: React.FC = () => {
  return (
    <div className="page-container">
      <h1>Settings</h1>
      <p>Adjust your application settings.</p>
    </div>
  );
};

export default Settings;