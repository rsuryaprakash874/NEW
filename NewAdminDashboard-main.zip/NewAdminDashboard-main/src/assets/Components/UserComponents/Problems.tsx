import React from 'react';
import './styles.css';
const Problems: React.FC = () => {
  return (
    <div className="page-container">
      <h1>Problems</h1>
      <p>Browse and solve coding problems.</p>
    </div>
  );
};

export default Problems;